package Clase;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class CrearArchivoSecuencial {

    private static ObjectOutputStream salida;

    public static void main(String[] args) {
        abrirArchivo();
        agregarRegistros();
        cerrarArchivo();
    }

    public static void abrirArchivo() {
        try {
            salida = new ObjectOutputStream(Files.newOutputStream(Paths.get("clientes.ser")));
        } catch (IOException ioException) {
            System.err.println("Error al abrir el archivo.Terminando.");
            System.exit(1);
        }
    }

    public static void agregarRegistros() {
        Scanner entrada = new Scanner(System.in);
        System.out.printf("%s%n%s%n?", "Escriba numero de cuenta, primer nombre, apellido paterno y saldo.",
                "Escriba el indicador de fin de archivo para terminar la entrada.");

        while (entrada.hasNext()) {
            try {
                Cuenta registro = new Cuenta(entrada.nextInt(), entrada.next(), entrada.next(), entrada.nextDouble());
                salida.writeObject(registro);
            } catch (NoSuchElementException elementException) {
                System.err.println("Entrada invalida. Intente de nuevo");
                entrada.nextLine();
            } catch (IOException ioException) {
                System.err.println("Error al escribir en el archivo. Terminado");
                break;
            }
            System.out.println("? ");
        }
    }

    public static void cerrarArchivo() {
        try {
            if (salida != null) {
                salida.close();
            }
        } catch (IOException ioException) {
            System.err.println("Error al cerrar el archivo. Terminado.");
        }

    }

}
