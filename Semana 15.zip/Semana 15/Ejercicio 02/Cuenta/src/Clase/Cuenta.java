
package Clase;

import java.io.Serializable;

public class Cuenta implements Serializable{
    private int cuenta;
    private String primerNombre;
    private String apellidoParterno;
    private double saldo;
    
    public Cuenta(){
        this(0,"","",0.0);
    }
    
    public Cuenta(int cuenta, String primerNombre,String apellidoPaterno, double saldo){
        this.cuenta=cuenta;
        this.primerNombre=primerNombre;
        this.apellidoParterno=apellidoPaterno;
        this.saldo=saldo;
    }
    
    public void establecerCuenta(int cuenta){
        this.cuenta=cuenta;
    }
    
    public int obtenerCuenta(){
        return cuenta;
    }
    
    public void establecerPrimerNombre(String primerNombre){
        this.primerNombre=primerNombre;
    }
    public String obtenerPrimerNombre(){
        return primerNombre;
    }
    
    public void establecerApellidoPaterno(String apellidoPaterno){
        this.apellidoParterno=apellidoPaterno;
    }
    
    public String obtenerApellidoPaterno(){
        return apellidoParterno;
    }
    
    public void establecerSaldo(double saldo){
        this.saldo=saldo;
    }
    
    public double obtenerSaldo(){
        return saldo;
    }
}
