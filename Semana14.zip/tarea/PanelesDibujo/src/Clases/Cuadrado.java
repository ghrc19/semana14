package Clases;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Cuadrado extends Thread {

    public void Dibujar(Graphics g){
        int aux;
        for (int i = 0; i < 7; i++) {
            aux=10*i;
            try{
                sleep(1000);
            }catch(Exception e){
                
            }
            g.drawRect(10+aux,10+aux,50+aux,50+aux);
        }
    }

}
