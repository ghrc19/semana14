
package Clases;

import java.awt.Graphics;
import static java.lang.Thread.sleep;

public class Circulo {
    public void Dibujar(Graphics g){
        int aux;
        for (int i = 0; i < 7; i++) {
            aux=10*i;
            try{
                sleep(1000);
            }catch(Exception e){
                
            }
            g.drawOval(10+aux,10+aux,50+aux,50+aux);
        }
    }
}
