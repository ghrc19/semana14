package Aplica;

import java.awt.Color;
import java.util.Random;

public class Aplica extends javax.swing.JFrame {

    public Aplica() {
        initComponents();
        p.start();
    }

    public class pintar extends Thread {

        @Override
        public void run() {
            for (int i = 0; i < 100; i++) {
                try {
                    sleep(200);
                } catch (Exception e) {
                }
                Random r = new Random();
                for (int j = 0; j < 10; j++) {
                    int aleatorio1 = r.nextInt(7);
                    switch (aleatorio1) {
                        case 0:
                            a1.setBackground(Color.white);
                            a2.setBackground(Color.white);
                            a3.setBackground(Color.white);
                            a4.setBackground(Color.white);
                            a5.setBackground(Color.white);
                            a6.setBackground(Color.white);
                            break;
                        case 1:
                            a1.setBackground(Color.red);
                            a2.setBackground(Color.white);
                            a3.setBackground(Color.white);
                            a4.setBackground(Color.white);
                            a5.setBackground(Color.white);
                            a6.setBackground(Color.white);
                            break;
                        case 2:
                            a1.setBackground(Color.red);
                            a2.setBackground(Color.red);
                            a3.setBackground(Color.white);
                            a4.setBackground(Color.white);
                            a5.setBackground(Color.white);
                            a6.setBackground(Color.white);
                            break;
                        case 3:
                            a1.setBackground(Color.red);
                            a2.setBackground(Color.red);
                            a3.setBackground(Color.red);
                            a4.setBackground(Color.white);
                            a5.setBackground(Color.white);
                            a6.setBackground(Color.white);
                            break;
                        case 4:
                            a1.setBackground(Color.red);
                            a2.setBackground(Color.red);
                            a3.setBackground(Color.red);
                            a4.setBackground(Color.red);
                            a5.setBackground(Color.white);
                            a6.setBackground(Color.white);
                            break;
                        case 5:
                            a1.setBackground(Color.red);
                            a2.setBackground(Color.red);
                            a3.setBackground(Color.red);
                            a4.setBackground(Color.red);
                            a5.setBackground(Color.red);
                            a6.setBackground(Color.white);
                            break;
                        case 6:
                            a1.setBackground(Color.red);
                            a2.setBackground(Color.red);
                            a3.setBackground(Color.red);
                            a4.setBackground(Color.red);
                            a5.setBackground(Color.red);
                            a6.setBackground(Color.red);
                            break;

                    }
                    int aleatorio2 = r.nextInt(7);
                    switch (aleatorio2) {
                        case 0:
                            b1.setBackground(Color.white);
                            b2.setBackground(Color.white);
                            b3.setBackground(Color.white);
                            b4.setBackground(Color.white);
                            b5.setBackground(Color.white);
                            b6.setBackground(Color.white);
                            break;
                        case 1:
                            b1.setBackground(Color.red);
                            b2.setBackground(Color.white);
                            b3.setBackground(Color.white);
                            b4.setBackground(Color.white);
                            b5.setBackground(Color.white);
                            b6.setBackground(Color.white);
                            break;
                        case 2:
                            b1.setBackground(Color.red);
                            b2.setBackground(Color.red);
                            b3.setBackground(Color.white);
                            b4.setBackground(Color.white);
                            b5.setBackground(Color.white);
                            b6.setBackground(Color.white);
                            break;
                        case 3:
                            b1.setBackground(Color.red);
                            b2.setBackground(Color.red);
                            b3.setBackground(Color.red);
                            b4.setBackground(Color.white);
                            b5.setBackground(Color.white);
                            b6.setBackground(Color.white);
                            break;
                        case 4:
                            b1.setBackground(Color.red);
                            b2.setBackground(Color.red);
                            b3.setBackground(Color.red);
                            b4.setBackground(Color.red);
                            b5.setBackground(Color.white);
                            b6.setBackground(Color.white);
                            break;
                        case 5:
                            b1.setBackground(Color.red);
                            b2.setBackground(Color.red);
                            b3.setBackground(Color.red);
                            b4.setBackground(Color.red);
                            b5.setBackground(Color.red);
                            b6.setBackground(Color.white);
                            break;
                        case 6:
                            b1.setBackground(Color.red);
                            b2.setBackground(Color.red);
                            b3.setBackground(Color.red);
                            b4.setBackground(Color.red);
                            b5.setBackground(Color.red);
                            b6.setBackground(Color.red);
                            break;

                    }
                    int aleatorio3 = r.nextInt(7);
                    switch (aleatorio3) {
                        case 0:
                            c1.setBackground(Color.white);
                            c2.setBackground(Color.white);
                            c3.setBackground(Color.white);
                            c4.setBackground(Color.white);
                            c5.setBackground(Color.white);
                            c6.setBackground(Color.white);
                            break;
                        case 1:
                            c1.setBackground(Color.red);
                            c2.setBackground(Color.white);
                            c3.setBackground(Color.white);
                            c4.setBackground(Color.white);
                            c5.setBackground(Color.white);
                            c6.setBackground(Color.white);
                            break;
                        case 2:
                            c1.setBackground(Color.red);
                            c2.setBackground(Color.red);
                            c3.setBackground(Color.white);
                            c4.setBackground(Color.white);
                            c5.setBackground(Color.white);
                            c6.setBackground(Color.white);
                            break;
                        case 3:
                            c1.setBackground(Color.red);
                            c2.setBackground(Color.red);
                            c3.setBackground(Color.red);
                            c4.setBackground(Color.white);
                            c5.setBackground(Color.white);
                            c6.setBackground(Color.white);
                            break;
                        case 4:
                            c1.setBackground(Color.red);
                            c2.setBackground(Color.red);
                            c3.setBackground(Color.red);
                            c4.setBackground(Color.red);
                            c5.setBackground(Color.white);
                            c6.setBackground(Color.white);
                            break;
                        case 5:
                            c1.setBackground(Color.red);
                            c2.setBackground(Color.red);
                            c3.setBackground(Color.red);
                            c4.setBackground(Color.red);
                            c5.setBackground(Color.red);
                            c6.setBackground(Color.white);
                            break;
                        case 6:
                            c1.setBackground(Color.red);
                            c2.setBackground(Color.red);
                            c3.setBackground(Color.red);
                            c4.setBackground(Color.red);
                            c5.setBackground(Color.red);
                            c6.setBackground(Color.red);
                            break;

                    }
                    int aleatorio4 = r.nextInt(7);
                    switch (aleatorio4) {
                        case 0:
                            d1.setBackground(Color.white);
                            d2.setBackground(Color.white);
                            d3.setBackground(Color.white);
                            d4.setBackground(Color.white);
                            d5.setBackground(Color.white);
                            d6.setBackground(Color.white);
                            break;
                        case 1:
                            d1.setBackground(Color.red);
                            d2.setBackground(Color.white);
                            d3.setBackground(Color.white);
                            d4.setBackground(Color.white);
                            d5.setBackground(Color.white);
                            d6.setBackground(Color.white);
                            break;
                        case 2:
                            d1.setBackground(Color.red);
                            d2.setBackground(Color.red);
                            d3.setBackground(Color.white);
                            d4.setBackground(Color.white);
                            d5.setBackground(Color.white);
                            d6.setBackground(Color.white);
                            break;
                        case 3:
                            d1.setBackground(Color.red);
                            d2.setBackground(Color.red);
                            d3.setBackground(Color.red);
                            d4.setBackground(Color.white);
                            d5.setBackground(Color.white);
                            d6.setBackground(Color.white);
                            break;
                        case 4:
                            d1.setBackground(Color.red);
                            d2.setBackground(Color.red);
                            d3.setBackground(Color.red);
                            d4.setBackground(Color.red);
                            d5.setBackground(Color.white);
                            d6.setBackground(Color.white);
                            break;
                        case 5:
                            d1.setBackground(Color.red);
                            d2.setBackground(Color.red);
                            d3.setBackground(Color.red);
                            d4.setBackground(Color.red);
                            d5.setBackground(Color.red);
                            d6.setBackground(Color.white);
                            break;
                        case 6:
                            d1.setBackground(Color.red);
                            d2.setBackground(Color.red);
                            d3.setBackground(Color.red);
                            d4.setBackground(Color.red);
                            d5.setBackground(Color.red);
                            d6.setBackground(Color.red);
                            break;

                    }
                    int aleatorio5 = r.nextInt(7);
                    switch (aleatorio5) {
                        case 0:
                            e1.setBackground(Color.white);
                            e2.setBackground(Color.white);
                            e3.setBackground(Color.white);
                            e4.setBackground(Color.white);
                            e5.setBackground(Color.white);
                            e6.setBackground(Color.white);
                            break;
                        case 1:
                            e1.setBackground(Color.red);
                            e2.setBackground(Color.white);
                            e3.setBackground(Color.white);
                            e4.setBackground(Color.white);
                            e5.setBackground(Color.white);
                            e6.setBackground(Color.white);
                            break;
                        case 2:
                            e1.setBackground(Color.red);
                            e2.setBackground(Color.red);
                            e3.setBackground(Color.white);
                            e4.setBackground(Color.white);
                            e5.setBackground(Color.white);
                            e6.setBackground(Color.white);
                            break;
                        case 3:
                            e1.setBackground(Color.red);
                            e2.setBackground(Color.red);
                            e3.setBackground(Color.red);
                            e4.setBackground(Color.white);
                            e5.setBackground(Color.white);
                            e6.setBackground(Color.white);
                            break;
                        case 4:
                            e1.setBackground(Color.red);
                            e2.setBackground(Color.red);
                            e3.setBackground(Color.red);
                            e4.setBackground(Color.red);
                            e5.setBackground(Color.white);
                            e6.setBackground(Color.white);
                            break;
                        case 5:
                            e1.setBackground(Color.red);
                            e2.setBackground(Color.red);
                            e3.setBackground(Color.red);
                            e4.setBackground(Color.red);
                            e5.setBackground(Color.red);
                            e6.setBackground(Color.white);
                            break;
                        case 6:
                            e1.setBackground(Color.red);
                            e2.setBackground(Color.red);
                            e3.setBackground(Color.red);
                            e4.setBackground(Color.red);
                            e5.setBackground(Color.red);
                            e6.setBackground(Color.red);
                            break;

                    }
                }
            }
        }

    }
    pintar p = new pintar();

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        a6 = new javax.swing.JTextField();
        a4 = new javax.swing.JTextField();
        a5 = new javax.swing.JTextField();
        a3 = new javax.swing.JTextField();
        a2 = new javax.swing.JTextField();
        a1 = new javax.swing.JTextField();
        b6 = new javax.swing.JTextField();
        b4 = new javax.swing.JTextField();
        b5 = new javax.swing.JTextField();
        b3 = new javax.swing.JTextField();
        b2 = new javax.swing.JTextField();
        b1 = new javax.swing.JTextField();
        c6 = new javax.swing.JTextField();
        c4 = new javax.swing.JTextField();
        c5 = new javax.swing.JTextField();
        c3 = new javax.swing.JTextField();
        c2 = new javax.swing.JTextField();
        c1 = new javax.swing.JTextField();
        d6 = new javax.swing.JTextField();
        d4 = new javax.swing.JTextField();
        d5 = new javax.swing.JTextField();
        d3 = new javax.swing.JTextField();
        d2 = new javax.swing.JTextField();
        d1 = new javax.swing.JTextField();
        e6 = new javax.swing.JTextField();
        e4 = new javax.swing.JTextField();
        e5 = new javax.swing.JTextField();
        e3 = new javax.swing.JTextField();
        e2 = new javax.swing.JTextField();
        e1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        a6.setEditable(false);

        a4.setEditable(false);

        a5.setEditable(false);

        a3.setEditable(false);

        a2.setEditable(false);

        a1.setEditable(false);

        b6.setEditable(false);

        b4.setEditable(false);

        b5.setEditable(false);

        b3.setEditable(false);

        b2.setEditable(false);

        b1.setEditable(false);

        c6.setEditable(false);

        c4.setEditable(false);

        c5.setEditable(false);

        c3.setEditable(false);

        c2.setEditable(false);

        c1.setEditable(false);

        d6.setEditable(false);

        d4.setEditable(false);

        d5.setEditable(false);

        d3.setEditable(false);

        d2.setEditable(false);

        d1.setEditable(false);

        e6.setEditable(false);

        e4.setEditable(false);

        e5.setEditable(false);

        e3.setEditable(false);

        e2.setEditable(false);

        e1.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(a1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(a2, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(a3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(a5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(a4, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(a6, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(c1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c2, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c4, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c6, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(d1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(d2, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(d3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(d5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(d4, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(d6, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(e1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(e2, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(e3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(e5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(e4, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(e6, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(e6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(e5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(e4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(e3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(e2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(e1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(d6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(d5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(d4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(d3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(d2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(d1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(c6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(a6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(a5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(a4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(a3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(a2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(a1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Aplica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Aplica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Aplica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Aplica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Aplica().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField a1;
    private javax.swing.JTextField a2;
    private javax.swing.JTextField a3;
    private javax.swing.JTextField a4;
    private javax.swing.JTextField a5;
    private javax.swing.JTextField a6;
    private javax.swing.JTextField b1;
    private javax.swing.JTextField b2;
    private javax.swing.JTextField b3;
    private javax.swing.JTextField b4;
    private javax.swing.JTextField b5;
    private javax.swing.JTextField b6;
    private javax.swing.JTextField c1;
    private javax.swing.JTextField c2;
    private javax.swing.JTextField c3;
    private javax.swing.JTextField c4;
    private javax.swing.JTextField c5;
    private javax.swing.JTextField c6;
    private javax.swing.JTextField d1;
    private javax.swing.JTextField d2;
    private javax.swing.JTextField d3;
    private javax.swing.JTextField d4;
    private javax.swing.JTextField d5;
    private javax.swing.JTextField d6;
    private javax.swing.JTextField e1;
    private javax.swing.JTextField e2;
    private javax.swing.JTextField e3;
    private javax.swing.JTextField e4;
    private javax.swing.JTextField e5;
    private javax.swing.JTextField e6;
    // End of variables declaration//GEN-END:variables
}
